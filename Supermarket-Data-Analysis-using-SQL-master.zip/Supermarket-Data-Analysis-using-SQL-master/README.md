# Supermarket-Data-Analysis-using-SQL
MySQL Script to Create Reports for Multiple Business Scenarios

In this project, I used MySQL to create a relational databse, import the data and then extract different information to asnwer different business questions. This questions include: Top products based on day of the week, location, regular shopping path of the customers, associations in customers orders.
